import express, { Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { jwtAuthenticationFilter, requireRole } from './middleware/jwtFilter.js';
import { authRouter } from './controllers/authController.js';
import { adminRouter } from './controllers/adminController.js';
import { productRouter } from './controllers/productController.js';
import { orderRouter } from './controllers/orderController.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json());

// Public healthcheck
app.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'UP',
    securityEngine: 'Spring Security 6.x Specification',
    timestamp: new Date().toISOString()
  });
});

// Mount Spring Security Filter Chain
app.use('/api', jwtAuthenticationFilter);

// Routes
app.use('/api/auth', authRouter);
app.use('/api/products', productRouter);
app.use('/api/orders', orderRouter);

// Strict Spring Security Barrier: /api/admin/** requires ROLE_ADMIN
app.use('/api/admin', requireRole('ROLE_ADMIN'), adminRouter);

app.listen(PORT, () => {
  console.log(`[SpringSecurity Engine] ApexStore REST API listening on port ${PORT}`);
  console.log(`[SecurityFilterChain] /api/admin/** strictly locked to ROLE_ADMIN`);
});
