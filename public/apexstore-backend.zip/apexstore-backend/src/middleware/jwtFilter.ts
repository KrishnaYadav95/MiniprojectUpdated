import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'apex_super_secure_spring_jwt_token_secret_key_2026';

export interface SpringPrincipal {
  sub: string;
  email: string;
  name: string;
  roles: string[];
  authorities: string[];
}

declare global {
  namespace Express {
    interface Request {
      securityContext?: {
        principal: SpringPrincipal;
        authenticated: boolean;
      };
    }
  }
}

/**
 * Spring Security JwtAuthenticationFilter
 * Extracts Bearer token from Authorization header and sets SecurityContextHolder equivalent
 */
export function jwtAuthenticationFilter(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next();
  }

  const token = authHeader.substring(7);
  try {
    const decoded = jwt.decode(token) as SpringPrincipal;
    if (decoded && decoded.sub) {
      req.securityContext = {
        principal: decoded,
        authenticated: true
      };
    }
  } catch (err) {
    console.warn('[JwtFilter] Invalid token presented:', err);
  }

  next();
}

/**
 * Spring Security AuthorizationFilter
 * Evaluates .requestMatchers(path).hasRole(role)
 */
export function requireRole(requiredAuthority: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    const context = req.securityContext;

    if (!context || !context.authenticated) {
      return res.status(401).json({
        timestamp: new Date().toISOString(),
        status: 401,
        error: 'Unauthorized',
        message: 'Full authentication is required to access this resource. No valid Bearer token found.',
        path: req.originalUrl
      });
    }

    const authorities = context.principal.authorities || [];
    if (!authorities.includes(requiredAuthority)) {
      return res.status(403).json({
        timestamp: new Date().toISOString(),
        status: 403,
        error: 'Forbidden',
        message: `Access Denied: Principal [${context.principal.email}] does not possess granted authority [${requiredAuthority}].`,
        path: req.originalUrl,
        requiredAuthority,
        grantedAuthorities: authorities
      });
    }

    next();
  };
}
