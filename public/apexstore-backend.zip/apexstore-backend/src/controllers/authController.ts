import { Router, Request, Response } from 'express';
import jwt from 'jsonwebtoken';

export const authRouter = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'apex_super_secure_spring_jwt_token_secret_key_2026';

// In-memory admin database initialized with default administrator credentials
let adminAccounts = [
  {
    id: 'adm-001',
    username: 'admin',
    email: 'admin@apexstore.com',
    password: 'Admin@2026!',
    name: 'Sarah Connor',
    authority: 'ROLE_ADMIN'
  },
  {
    id: 'adm-002',
    username: 'superadmin',
    email: 'root@apexstore.internal',
    password: 'ApexSecure#99',
    name: 'Chief Security Officer',
    authority: 'ROLE_ADMIN'
  }
];

// POST /api/auth/admin/login
authRouter.post('/admin/login', (req: Request, res: Response) => {
  const { usernameOrEmail, password } = req.body;
  const cleanInput = (usernameOrEmail || '').trim().toLowerCase();

  const found = adminAccounts.find(
    a => a.username.toLowerCase() === cleanInput || a.email.toLowerCase() === cleanInput
  );

  if (!found || found.password !== password) {
    return res.status(401).json({
      timestamp: new Date().toISOString(),
      status: 401,
      error: 'BadCredentialsException',
      message: 'Invalid administrator credentials.'
    });
  }

  // Issue Spring Security compatible JWT
  const token = jwt.sign(
    {
      sub: found.email,
      email: found.email,
      name: found.name,
      roles: ['ROLE_ADMIN'],
      authorities: ['ROLE_ADMIN'],
      iss: 'org.springframework.security.apexstore'
    },
    JWT_SECRET,
    { expiresIn: '24h' }
  );

  res.json({
    token,
    admin: {
      id: found.id,
      username: found.username,
      name: found.name,
      email: found.email,
      authority: found.authority
    }
  });
});
