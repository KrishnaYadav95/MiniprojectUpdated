import { Router, Request, Response } from 'express';

export const productRouter = Router();

// GET /api/products
productRouter.get('/', (req: Request, res: Response) => {
  res.json({
    count: 104,
    categories: ['All', 'Electronics', 'Apparel', 'Audio', 'Footwear', 'Accessories', 'Smart Home'],
    message: 'Master catalog endpoint - 104 active SKUs'
  });
});
