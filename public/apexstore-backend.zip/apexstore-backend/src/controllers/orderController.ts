import { Router, Request, Response } from 'express';

export const orderRouter = Router();

// In-memory customer orders
let orders: any[] = [];

// POST /api/orders
orderRouter.post('/', (req: Request, res: Response) => {
  const newOrder = {
    id: `ORD-${Date.now()}`,
    timestamp: new Date().toISOString(),
    ...req.body
  };
  orders.unshift(newOrder);
  res.status(201).json(newOrder);
});

// GET /api/orders
orderRouter.get('/', (req: Request, res: Response) => {
  res.json(orders);
});
