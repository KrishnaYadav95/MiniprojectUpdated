package com.apexstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApexStoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApexStoreApplication.class, args);
    }
}
