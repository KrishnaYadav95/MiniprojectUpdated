# ApexStore - Backend Architecture & Services

This package contains the backend implementation and security specifications for **ApexStore**.

## 🛡️ Architecture Overview
The backend is structured to enforce enterprise-grade **Spring Security 6.x** access controls:
1. **Public Endpoints**: `/api/products/**`, `/api/auth/**` (open access for catalog browsing and authentication).
2. **User Endpoints**: `/api/orders/**` (requires valid customer or admin token).
3. **Admin Endpoints**: `/api/admin/**` (strictly enforced `hasRole("ADMIN")`, rejected with HTTP 403 Forbidden for anyone without `ROLE_ADMIN`).

## 📦 What's Inside This Archive
```text
apexstore-backend/
├── src/                               # Node.js / Express + TypeScript REST API
│   ├── server.ts                      # Express API entry point with SecurityFilterChain
│   ├── middleware/
│   │   └── jwtFilter.ts               # Spring Security JWT & Authorization Filter
│   └── controllers/
│       ├── authController.ts          # Admin authentication & token generation
│       ├── adminController.ts         # Inventory updates, analytics reset, dashboard ops
│       ├── productController.ts       # 100+ product catalog endpoints
│       └── orderController.ts         # Order placement and history
├── spring-boot/                       # Official Java Spring Boot 3 reference implementation
│   ├── pom.xml                        # Maven dependencies (Spring Boot 3.2.3, Spring Security 6)
│   └── src/main/java/com/apexstore/
│       ├── ApexStoreApplication.java
│       ├── config/SecurityConfig.java # Spring SecurityFilterChain configuration
│       └── security/JwtAuthenticationFilter.java
├── firestore.rules                    # Cloud Firestore database security rules
├── firebase-blueprint.json            # Database blueprint and collection schema
├── package.json                       # Node backend dependencies
└── tsconfig.json
```

## 🚀 Running the Node.js / Express REST Backend
```bash
npm install
npm run dev
```
The REST server will start at `http://localhost:8080`.

## ☕ Running the Java Spring Boot 3 Backend
```bash
cd spring-boot
mvn clean spring-boot:run
```
The Spring Boot server will run at `http://localhost:8080`.

## 🔑 Default Administrator Credentials
- **Username:** `admin`
- **Password:** `Admin@2026!`
- **Role Authority:** `ROLE_ADMIN`
