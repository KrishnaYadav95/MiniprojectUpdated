import React, { useState } from 'react';
import {
  Download,
  X,
  FileCode,
  Server,
  Layers,
  CheckCircle2,
  Terminal,
  ShieldCheck,
  Package,
  ExternalLink
} from 'lucide-react';

interface DownloadCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadCodeModal: React.FC<DownloadCodeModalProps> = ({ isOpen, onClose }) => {
  const [downloadedItem, setDownloadedItem] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownload = (name: string) => {
    setDownloadedItem(name);
    setTimeout(() => setDownloadedItem(null), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-stone-50/70 dark:bg-stone-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <span>Download Source Code Packages</span>
                <span className="text-[10px] font-mono uppercase bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-bold px-2 py-0.5 rounded">
                  ZIP Export
                </span>
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                Standalone Frontend & Backend ZIP files ready for local extraction and deployment.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {downloadedItem && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center gap-2 text-emerald-800 dark:text-emerald-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span><strong>{downloadedItem}</strong> started downloading to your computer!</span>
            </div>
          )}

          {/* Cards for Frontend & Backend */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* FRONTEND CARD */}
            <div className="border border-stone-200 dark:border-stone-800 rounded-xl p-4 bg-white dark:bg-stone-900/60 hover:border-indigo-300 dark:hover:border-indigo-700/60 transition flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center font-bold">
                      <FileCode className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-stone-900 dark:text-stone-100 text-sm">
                      Frontend Package
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-stone-400 font-semibold bg-stone-100 dark:bg-stone-800 px-2 py-0.5 rounded">
                    ~107 KB (.zip)
                  </span>
                </div>
                <p className="text-stone-500 dark:text-stone-400 text-[11px] leading-relaxed">
                  Complete client-side web application built with React 19, TypeScript, Tailwind CSS, and Vite.
                </p>
                <ul className="mt-2.5 space-y-1 text-[11px] text-stone-600 dark:text-stone-300">
                  <li className="flex items-center gap-1.5">
                    <span className="text-emerald-500 font-bold">✓</span> 104-product catalog with images & filters
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="text-emerald-500 font-bold">✓</span> Secured Admin Console & 403 Forbidden barrier
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="text-emerald-500 font-bold">✓</span> Sales analytics charts with Reset feature
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="text-emerald-500 font-bold">✓</span> Shopping cart, checkout & order tracking
                  </li>
                </ul>
              </div>

              <a
                href="/apexstore-frontend.zip"
                download="apexstore-frontend.zip"
                onClick={() => handleDownload('apexstore-frontend.zip')}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Frontend (.zip)</span>
              </a>
            </div>

            {/* BACKEND CARD */}
            <div className="border border-stone-200 dark:border-stone-800 rounded-xl p-4 bg-white dark:bg-stone-900/60 hover:border-emerald-300 dark:hover:border-emerald-700/60 transition flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                      <Server className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-stone-900 dark:text-stone-100 text-sm">
                      Backend Package
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-stone-400 font-semibold bg-stone-100 dark:bg-stone-800 px-2 py-0.5 rounded">
                    ~15 KB (.zip)
                  </span>
                </div>
                <p className="text-stone-500 dark:text-stone-400 text-[11px] leading-relaxed">
                  Spring Security 6 & REST API backend services (Node.js/Express + Java Spring Boot 3 reference).
                </p>
                <ul className="mt-2.5 space-y-1 text-[11px] text-stone-600 dark:text-stone-300">
                  <li className="flex items-center gap-1.5">
                    <span className="text-emerald-500 font-bold">✓</span> Express / TS API with JWT Filter Chain
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="text-emerald-500 font-bold">✓</span> Java Spring Boot 3 & Spring Security 6 app
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="text-emerald-500 font-bold">✓</span> <code className="font-mono text-[10px] bg-stone-100 dark:bg-stone-800 px-1 py-0.5 rounded">/api/admin/**</code> restricted to <code className="font-mono text-[10px] bg-stone-100 dark:bg-stone-800 px-1 py-0.5 rounded">ROLE_ADMIN</code>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="text-emerald-500 font-bold">✓</span> Cloud Firestore security rules & schema
                  </li>
                </ul>
              </div>

              <a
                href="/apexstore-backend.zip"
                download="apexstore-backend.zip"
                onClick={() => handleDownload('apexstore-backend.zip')}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs shadow-xs transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Backend (.zip)</span>
              </a>
            </div>
          </div>

          {/* Combined Option */}
          <div className="border border-stone-200 dark:border-stone-800 rounded-xl p-3 bg-stone-50 dark:bg-stone-800/40 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Layers className="w-4 h-4 text-indigo-500 shrink-0" />
              <div>
                <span className="font-bold text-stone-900 dark:text-white">Full-Stack Bundle</span>
                <span className="text-stone-500 dark:text-stone-400 ml-1.5 text-[11px]">
                  (Both frontend and backend in one single archive: ~122 KB)
                </span>
              </div>
            </div>
            <a
              href="/apexstore-fullstack.zip"
              download="apexstore-fullstack.zip"
              onClick={() => handleDownload('apexstore-fullstack.zip')}
              className="px-3.5 py-1.5 bg-stone-900 hover:bg-stone-800 dark:bg-stone-100 dark:hover:bg-white text-white dark:text-stone-900 font-semibold rounded-lg text-xs transition inline-flex items-center gap-1.5 shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Combined (.zip)</span>
            </a>
          </div>

          {/* Quick Terminal Guide */}
          <div className="bg-stone-900 text-stone-200 rounded-xl p-3.5 font-mono text-[11px] space-y-2">
            <div className="flex items-center gap-2 text-stone-400 font-sans font-bold text-xs">
              <Terminal className="w-3.5 h-3.5 text-indigo-400" />
              <span>Quick Run Instructions</span>
            </div>
            <div className="space-y-1 text-stone-300">
              <div className="text-stone-400"># Frontend setup:</div>
              <div className="text-indigo-300">unzip apexstore-frontend.zip && cd apexstore-frontend</div>
              <div className="text-indigo-300">npm install && npm run dev</div>
              <div className="text-stone-400 pt-1"># Backend setup (Node.js/Express REST):</div>
              <div className="text-emerald-300">unzip apexstore-backend.zip && cd apexstore-backend</div>
              <div className="text-emerald-300">npm install && npm run dev</div>
            </div>
          </div>

          {/* Credentials Notice */}
          <div className="p-3 bg-stone-100 dark:bg-stone-800/80 rounded-xl flex items-center justify-between text-stone-600 dark:text-stone-300 text-[11px]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-indigo-500 shrink-0" />
              <span>Default Admin Login: <strong>admin</strong> / <strong>Admin@2026!</strong> (Authority: <code>ROLE_ADMIN</code>)</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-200 dark:border-stone-800 bg-stone-50/70 dark:bg-stone-950/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 hover:bg-stone-50 text-stone-700 dark:text-stone-200 rounded-lg text-xs font-semibold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
