# ApexStore - Frontend Application (React 19 + Vite + Tailwind CSS)

Welcome to the **ApexStore** frontend codebase! This repository contains the complete, high-performance customer storefront and secured administrative portal.

## 🚀 Key Features
- **100+ Product Catalog**: Over 104 curated products across Electronics, Apparel, Audio, Footwear, Accessories, and Smart Home with high-res photography, faceted filters, real-time search, sorting, and pagination.
- **Strict Spring Security Barrier**: Admin routes and panels strictly enforce `ROLE_ADMIN` verification. Standard user/customer accounts receive HTTP 403 Forbidden screens.
- **Admin Authentication**: Administrator login checks against the secure Admin Database stored in Cloud Firestore.
- **Inventory Management**: Real-time stock modification, low-stock threshold monitoring, pricing edits, and audit logging.
- **Sales Analytics with Graphs**: Interactive SVG charts (Revenue trends, Orders over time, Category distribution, Top selling SKUs) with a 1-click **Reset Sales Analytics** option.
- **User Role Management**: Inspect and manage registered users and cloud administrator accounts.
- **Shopping Cart & Checkout**: Slide-out cart, live order summary, and order tracking history.

## 🛠️ Quick Start

### 1. Requirements
- Node.js 18.x or 20.x+
- npm or pnpm or bun

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Development Server
```bash
npm run dev
```
The application will start at `http://localhost:3000` or `http://localhost:5173`.

### 4. Build for Production
```bash
npm run build
```
Outputs production static bundle to `dist/`.

## 📁 Project Structure
```text
src/
├── components/          # Reusable UI components
│   ├── admin/           # Admin Console views (Inventory, Analytics, Roles, Configuration, 403 screen)
│   ├── AdminLoginModal.tsx
│   ├── CartDrawer.tsx
│   ├── CheckoutModal.tsx
│   ├── Navbar.tsx
│   ├── ProductCard.tsx
│   ├── ProductCatalog.tsx
│   └── UserOrdersModal.tsx
├── context/             # React Context providers (AuthContext, StoreContext)
├── data/                # Initial 104-product catalog and categories
├── services/            # Spring Security JWT engine, Firestore sync, Admin DB
└── types/               # TypeScript interfaces and domain models
```

## 🔐 Admin Credentials
Default administrator credentials provisioned in Cloud Firestore:
- **Username:** `admin`
- **Password:** `Admin@2026!`
- **Role Authority:** `ROLE_ADMIN`
